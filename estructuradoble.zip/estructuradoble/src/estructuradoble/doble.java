
package estructuradoble;


public class doble {
    
    public int dato;
    doble siguiente,anterior;
    
    //constructor con info
    
    public doble(int elem, doble sig, doble ant){
        dato=elem;
        siguiente=sig;
        anterior=ant;
    }
    
    //constructor sin info
    
    public doble(int elem){
        this(elem,null,null);
    }
    
}
