
package estructuradoble;

import javax.swing.JOptionPane;



public class Estructuradoble {

    
    public static void main(String[] args) {
        
        listadoble listin = new listadoble();
        int option=0, elem;
        do{
            try{
                option=Integer.parseInt(JOptionPane.showInputDialog(null, 
                        " 1 Agregar un nodo al inicio \n" 
                        + " 2 Agregar un nodo al final \n" 
                        + " 3 Mostrar la lista de inicio a final \n" 
                        + " 4 Mostrar la lista de final a inicio \n"
                        + " 5 Salir\n"
                        + " Que desea hacer", "Menu de opciones", 
                        JOptionPane.INFORMATION_MESSAGE));
            
                
                switch(option){
                    case 1:
                        elem=Integer.parseInt(JOptionPane.showInputDialog(null, 
                                "Ingrese elemento del nodo", "Agregando nodo", JOptionPane.INFORMATION_MESSAGE));
                        listin.addinicio(elem);
                        break;
                    case 2:
                        elem=Integer.parseInt(JOptionPane.showInputDialog(null, 
                                "Ingrese elemento del nodo", "Agregando nodo al final", JOptionPane.INFORMATION_MESSAGE));
                        listin.addfinal(elem);
                        break;
                    case 3:
                        if (!listin.vacia()) {
                            listin.mostinifin();
                        }else{
                           JOptionPane.showMessageDialog(null, "Sin nodos"); 
                        }
                        
                        break;
                    case 4:
                         if (!listin.vacia()) {
                            listin.mostfinInicio();
                        }else{
                           JOptionPane.showMessageDialog(null, "Sin nodos"); 
                        }
                        
                        break;
                    case 5:
                        JOptionPane.showMessageDialog(null, "Fin de la aplicacion");
                        break;
                        
                    default:
                        JOptionPane.showMessageDialog(null, "Opcion no valida");
                
                }
                        
            }catch(NumberFormatException n){
                JOptionPane.showMessageDialog(null,"Error" + n.getMessage());
            }
        }while(option!=5);
        
        
    }
    
}
