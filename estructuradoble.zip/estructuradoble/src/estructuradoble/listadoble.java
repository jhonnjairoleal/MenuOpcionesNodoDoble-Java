
package estructuradoble;

import javax.swing.JOptionPane;


public class listadoble {
    
    //constructor inicia en null
    private doble inicio,fin;
    
    public listadoble(){
        inicio=fin=null;
    }
    
    // Metodo saber si la lista esta vacia
    
    public boolean vacia(){
        return inicio==null;
    }
    
    //Metodo agregar al final
    public void addfinal(int elem){
        if(!vacia()){
            fin=new doble(elem, null, fin);
            fin.anterior.siguiente=fin;
        }else{
            inicio=fin=new doble(elem);
        }
    }
    
    // Metodo agregar al inicio
    public void addinicio(int elem){
        if(!vacia()){
            inicio=new doble(elem, inicio, null);
            inicio.siguiente.anterior=inicio;
        }else{
            inicio=fin=new doble(elem);
        }
    }
    
    //Metodo mostrar lista inicio fin inicio
    public void mostinifin(){
        if(!vacia()){
            String datos="<->";
            doble aux=inicio;
            while(aux!=null){
                datos = datos + "[" + aux.dato + "]<->";
                aux=aux.siguiente;
            }
            JOptionPane.showMessageDialog(null, datos, 
                    " Lista Inicio a Fin ", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    // Metodo de Fin a Inicio
    
    public void mostfinInicio(){
        if(!vacia()){
            String datos="<->";
            doble aux=fin;
            while(aux!=null){
                datos = datos + "[" + aux.dato + "]<->";
                aux=aux.anterior;
            }
            JOptionPane.showMessageDialog(null, datos, 
                    " Lista Inicio a Fin ", JOptionPane.INFORMATION_MESSAGE);
        }
    
    }
    
    
}

